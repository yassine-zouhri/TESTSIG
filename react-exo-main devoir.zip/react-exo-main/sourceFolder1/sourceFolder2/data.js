 const data=[{key:'1',firstName:'ahmed', lastName:'Bouanani', class:'SIG3'},
{key:'2',firstName:'ahmed', lastName:'Bouanani', class:'SIG3'},
{key:'3',firstName:'ahmed', lastName:'Bouanani', class:'SIG3'},
{key:'4',firstName:'ahmed', lastName:'Bouanani', class:'SIG3'},
{key:'5',firstName:'ahmed', lastName:'Bouanani', class:'SIG3'}];

export const data1=[{key:'1',firstName:'ahmed', lastName:'Bakkali', class:'GI'},
{key:'2',firstName:'ahmed', lastName:'Bouanani', class:'SIG3'},
{key:'3',firstName:'ahmed', lastName:'Bouanani', class:'SIG3'},
{key:'4',firstName:'ahmed', lastName:'Bouanani', class:'SIG3'},
{key:'5',firstName:'ahmed', lastName:'Bouanani', class:'SIG3'}];

export default data;